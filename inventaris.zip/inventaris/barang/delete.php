<?php
require_once '../config/database.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = $_GET['id'];

try {
    $stmt = $pdo->prepare("DELETE FROM barang WHERE id = ?");
    $stmt->execute([$id]);
    
    $_SESSION['success_message'] = "Barang berhasil dihapus";
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Gagal menghapus barang: " . $e->getMessage();
}

header("Location: index.php");
exit();
?>