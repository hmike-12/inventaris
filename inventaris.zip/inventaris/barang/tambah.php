<?php
include '../config/database.php';

if (isset($_POST['submit'])) {
    $nama      = $_POST['nama'];
    $kategori  = $_POST['kategori'];
    $stok      = $_POST['stok'];
    $harga     = $_POST['harga'];
    $tanggal   = $_POST['tanggal'];

    // Validasi
    if ($nama == "" || $stok < 0 || $harga < 0) {
        header("Location: tambah.php?msg=invalid");
        exit;
    }

    $insert = mysqli_query($conn, "INSERT INTO barang (nama_barang, id_kategori, jumlah_stok, harga_barang, tanggal_masuk)
                                   VALUES ('$nama', '$kategori', '$stok', '$harga', '$tanggal')");

    if ($insert) {
        header("Location: index.php?msg=sukses");
    } else {
        header("Location: index.php?msg=gagal");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .action-buttons {
            margin-top: 20px;
            margin-bottom: 30px;
        }
        .form-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="form-container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="mb-0">Tambah Barang Baru</h2>
                <div class="export-buttons">
                    <a href="export.php?type=excel" class="btn btn-success btn-sm">
                        <i class="bi bi-file-earmark-excel"></i> Excel
                    </a>
                    <a href="export.php?type=pdf" class="btn btn-danger btn-sm">
                        <i class="bi bi-file-earmark-pdf"></i> PDF
                    </a>
                </div>
            </div>

            <form method="post">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="nama" class="form-label">Nama Barang</label>
                        <input type="text" class="form-control" id="nama" name="nama" required>
                    </div>
                    <div class="col-md-6">
                        <label for="kategori" class="form-label">Kategori</label>
                        <select class="form-select" id="kategori" name="kategori" required>
                            <?php
                            $kat = mysqli_query($conn, "SELECT * FROM kategori");
                            while ($k = mysqli_fetch_assoc($kat)) {
                                echo "<option value='{$k['id_kategori']}'>{$k['nama_kategori']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="stok" class="form-label">Jumlah Stok</label>
                        <input type="number" class="form-control" id="stok" name="stok" min="0" required>
                    </div>
                    <div class="col-md-4">
                        <label for="harga" class="form-label">Harga Satuan</label>
                        <input type="number" class="form-control" id="harga" name="harga" min="0" required>
                    </div>
                    <div class="col-md-4">
                        <label for="tanggal" class="form-label">Tanggal Masuk</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" required>
                    </div>
                </div>

                <div class="action-buttons d-flex justify-content-between">
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                    <button type="submit" name="submit" class="btn btn-primary">
                        <i class="bi bi-save"></i> Simpan Barang
                    </button>
                </div>
            </form>
        </div>
    </div>
    

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>