<?php
require_once '../config/database.php';

// Set headers to force download
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="laporan_barang.xls"');

// Fetch data from the database
$sql = "SELECT b.*, k.nama_kategori FROM barang b 
        JOIN kategori k ON b.kategori_id = k.id";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$barang = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Output the data in Excel format
echo "<table border='1'>";
echo "<thead>";
echo "<tr>";
echo "<th>ID</th>";
echo "<th>Nama Barang</th>";
echo "<th>Kategori</th>";
echo "<th>Stok</th>";
echo "<th>Harga</th>";
echo "<th>Tanggal Masuk</th>";
echo "</tr>";
echo "</thead>";
echo "<tbody>";

if (empty($barang)) {
    echo "<tr><td colspan='6' class='text-center'>Tidak ada data ditemukan</td></tr>";
} else {
    foreach ($barang as $item) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($item['id']) . "</td>";
        echo "<td>" . htmlspecialchars($item['nama_barang']) . "</td>";
        echo "<td>" . htmlspecialchars($item['nama_kategori']) . "</td>";
        echo "<td>" . $item['jumlah_stok'] . "</td>";
        echo "<td>Rp " . number_format($item['harga_barang'], 0, ',', '.') . "</td>";
        echo "<td>" . date('d/m/Y', strtotime($item['tanggal_masuk'])) . "</td>";
        echo "</tr>";
    }
}

echo "</tbody>";
echo "</table>";
?>