<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navigation.php';

// Get categories for dropdown
$stmt = $pdo->query("SELECT * FROM kategori");
$kategori = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_barang = $_POST['nama_barang'];
    $kategori_id = $_POST['kategori_id'];
    $jumlah_stok = $_POST['jumlah_stok'];
    $harga_barang = $_POST['harga_barang'];
    $tanggal_masuk = $_POST['tanggal_masuk'];
    
    // Validation
    $errors = [];
    if (empty($nama_barang)) {
        $errors[] = "Nama barang harus diisi";
    }
    if (!is_numeric($jumlah_stok) || $jumlah_stok < 0) {
        $errors[] = "Stok harus berupa angka positif";
    }
    if (!is_numeric($harga_barang) || $harga_barang <= 0) {
        $errors[] = "Harga harus berupa angka lebih dari 0";
    }
    
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO barang (nama_barang, kategori_id, jumlah_stok, harga_barang, tanggal_masuk) 
                                  VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$nama_barang, $kategori_id, $jumlah_stok, $harga_barang, $tanggal_masuk]);
            
            $_SESSION['success_message'] = "Barang berhasil ditambahkan";
            header("Location: index.php");
            exit();
        } catch (PDOException $e) {
            $errors[] = "Gagal menambahkan barang: " . $e->getMessage();
        }
    }
}
?>

<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h2>Tambah Barang</h2>
    
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form method="POST">
        <div class="form-group">
            <label for="nama_barang">Nama Barang</label>
            <input type="text" class="form-control" id="nama_barang" name="nama_barang" required>
        </div>
        
        <div class="form-group">
            <label for="kategori_id">Kategori</label>
            <select class="form-control" id="kategori_id" name="kategori_id" required>
                <option value="">Pilih Kategori</option>
                <?php foreach ($kategori as $k): ?>
                    <option value="<?= $k['id'] ?>"><?= htmlspecialchars($k['nama_kategori']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label for="jumlah_stok">Jumlah Stok</label>
            <input type="number" class="form-control" id="jumlah_stok" name="jumlah_stok" min="0" required>
        </div>
        
        <div class="form-group">
            <label for="harga_barang">Harga Barang</label>
            <input type="number" class="form-control" id="harga_barang" name="harga_barang" min="1" required>
        </div>
        
        <div class="form-group">
            <label for="tanggal_masuk">Tanggal Masuk</label>
            <input type="date" class="form-control" id="tanggal_masuk" name="tanggal_masuk" required>
        </div>
        
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
    </form>
</main>

<?php require_once '../includes/footer.php'; ?>