<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navigation.php';
?>

<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h2>Daftar Barang</h2>
    
    <div class="mb-3">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <a href="create.php" class="btn btn-primary">Tambah Barang</a>
            </div>
            <div>
            <a href="export.php" target="_blank" class="btn btn-success">
  Export Excel
</a>

                
            </div>
        </div>
        
        <form class="form-inline mt-3" method="GET">
            <div class="input-group mr-2">
                <input type="text" class="form-control" name="search" placeholder="Cari nama barang..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="submit">Cari</button>
                </div>
            </div>
            
            <select name="kategori" class="form-control mr-2">
                <option value="">Semua Kategori</option>
                <?php 
                $kategori_stmt = $pdo->query("SELECT * FROM kategori");
                $kategori = $kategori_stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($kategori as $k): ?>
                    <option value="<?= $k['id'] ?>" <?= isset($_GET['kategori']) && $_GET['kategori'] == $k['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($k['nama_kategori']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-info">Filter</button>
        </form>
    </div>

    <?php
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $kategori_filter = isset($_GET['kategori']) ? $_GET['kategori'] : '';
    
    $sql = "SELECT b.*, k.nama_kategori FROM barang b 
            JOIN kategori k ON b.kategori_id = k.id 
            WHERE b.nama_barang LIKE :search";
    
    $params = [':search' => "%$search%"];
    
    if (!empty($kategori_filter)) {
        $sql .= " AND b.kategori_id = :kategori";
        $params[':kategori'] = $kategori_filter;
    }
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $barang = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Stok</th>
                    <th>Harga</th>
                    <th>Tanggal Masuk</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($barang)): ?>
                    <tr>
                        <td colspan="7" class="text-center">Tidak ada data ditemukan</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($barang as $item): ?>
                    <tr>
                        <td><?= $item['id'] ?></td>
                        <td><?= htmlspecialchars($item['nama_barang']) ?></td>
                        <td><?= htmlspecialchars($item['nama_kategori']) ?></td>
                        <td><?= $item['jumlah_stok'] ?></td>
                        <td>Rp <?= number_format($item['harga_barang'], 0, ',', '.') ?></td>
                        <td><?= date('d/m/Y', strtotime($item['tanggal_masuk'])) ?></td>
                        <td>
                            <a href="edit.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="delete.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

<?php require_once '../includes/footer.php'; ?>