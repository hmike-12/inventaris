<?php
require_once '../config/database.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = $_GET['id'];

try {
    // Check if category is used in barang
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM barang WHERE kategori_id = ?");
    $stmt->execute([$id]);
    $count = $stmt->fetchColumn();
    
    if ($count > 0) {
        $_SESSION['error_message'] = "Kategori tidak dapat dihapus karena masih digunakan oleh barang";
    } else {
        $stmt = $pdo->prepare("DELETE FROM kategori WHERE id = ?");
        $stmt->execute([$id]);
        $_SESSION['success_message'] = "Kategori berhasil dihapus";
    }
} catch (PDOException $e) {
    $_SESSION['error_message'] = "Gagal menghapus kategori: " . $e->getMessage();
}

header("Location: index.php");
exit();
?>