<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navigation.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';
$sql = "SELECT * FROM kategori WHERE nama_kategori LIKE :search ORDER BY nama_kategori";
$stmt = $pdo->prepare($sql);
$stmt->execute([':search' => "%$search%"]);
$kategori = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h2>Daftar Kategori</h2>
    
    <div class="mb-3">
        <a href="create.php" class="btn btn-primary">Tambah Kategori</a>
        <form class="form-inline float-right" method="GET">
            <div class="input-group">
                <input type="text" class="form-control" name="search" placeholder="Cari kategori...">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="submit">Cari</button>
                </div>
            </div>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Kategori</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($kategori as $item): ?>
                <tr>
                    <td><?= $item['id'] ?></td>
                    <td><?= htmlspecialchars($item['nama_kategori']) ?></td>
                    <td>
                        <a href="edit.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="delete.php?id=<?= $item['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php require_once '../includes/footer.php'; ?>