<?php
require_once '../config/database.php';
require_once '../includes/header.php';
require_once '../includes/navigation.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_kategori = $_POST['nama_kategori'];
    
    // Validation
    $errors = [];
    if (empty($nama_kategori)) {
        $errors[] = "Nama kategori harus diisi";
    }
    
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO kategori (nama_kategori) VALUES (?)");
            $stmt->execute([$nama_kategori]);
            
            $_SESSION['success_message'] = "Kategori berhasil ditambahkan";
            header("Location: index.php");
            exit();
        } catch (PDOException $e) {
            $errors[] = "Gagal menambahkan kategori: " . $e->getMessage();
        }
    }
}
?>

<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h2>Tambah Kategori</h2>
    
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form method="POST">
        <div class="form-group">
            <label for="nama_kategori">Nama Kategori</label>
            <input type="text" class="form-control" id="nama_kategori" name="nama_kategori" required>
        </div>
        
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
    </form>
</main>

<?php require_once '../includes/footer.php'; ?>