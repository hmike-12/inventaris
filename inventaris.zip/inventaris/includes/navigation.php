<!-- navigation.php -->
<nav class="col-md-2 d-none d-md-block bg-white sidebar shadow-sm position-relative min-vh-100 border-end">
  <div class="d-flex flex-column p-3 h-100">
    <a href="../index.php" class="d-flex align-items-center mb-4 mb-md-0 me-md-auto text-decoration-none">
      <i class="bi bi-box-seam fs-4 text-primary me-2"></i>
      <span class="fs-5 fw-bold text-dark">Inventaris</span>
    </a>
    <hr>

    <ul class="nav nav-pills flex-column mb-auto">
      <li class="nav-item mb-2">
        <a href="../index.php" class="nav-link text-dark d-flex align-items-center">
          <i class="bi bi-house-door me-2"></i> Dashboard
        </a>
      </li>
      <li class="nav-item mb-2">
        <a href="../barang/index.php" class="nav-link text-dark d-flex align-items-center">
          <i class="bi bi-box me-2"></i> Manajemen Barang
        </a>
      </li>
      <li class="nav-item mb-2">
        <a href="../kategori/index.php" class="nav-link text-dark d-flex align-items-center">
          <i class="bi bi-tags me-2"></i> Manajemen Kategori
        </a>
      </li>
    </ul>

    <hr class="mt-auto">
    <div class="dropdown">
      <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false">
        <img src="https://via.placeholder.com/30" alt="User" width="30" height="30" class="rounded-circle me-2">
        <strong>Admin</strong>
      </a>
      <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="dropdownUser">
        <li><a class="dropdown-item" href="#">Profile</a></li>
        <li><a class="dropdown-item" href="#">Settings</a></li>
        <li><hr class="dropdown-divider"></li>
        <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
