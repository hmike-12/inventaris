<?php
require_once 'config/database.php';
require_once 'includes/header.php';
require_once 'includes/navigation.php';

// Count total items
$stmt = $pdo->query("SELECT COUNT(*) FROM barang");
$total_barang = $stmt->fetchColumn();

// Count total categories
$stmt = $pdo->query("SELECT COUNT(*) FROM kategori");
$total_kategori = $stmt->fetchColumn();

// Get recent items
$stmt = $pdo->query("SELECT b.*, k.nama_kategori FROM barang b 
                     JOIN kategori k ON b.kategori_id = k.id 
                     ORDER BY b.tanggal_masuk DESC LIMIT 5");
$recent_barang = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h2>Dashboard</h2>
    
    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card text-white bg-primary mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Barang</h5>
                    <p class="card-text display-4"><?= $total_barang ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card text-white bg-success mb-3">
                <div class="card-body">
                    <h5 class="card-title">Total Kategori</h5>
                    <p class="card-text display-4"><?= $total_kategori ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card">
        <div class="card-header">
            <h5>Barang Terbaru</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Nama Barang</th>
                            <th>Kategori</th>
                            <th>Stok</th>
                            <th>Harga</th>
                            <th>Tanggal Masuk</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_barang as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['nama_barang']) ?></td>
                            <td><?= htmlspecialchars($item['nama_kategori']) ?></td>
                            <td><?= $item['jumlah_stok'] ?></td>
                            <td>Rp <?= number_format($item['harga_barang'], 0, ',', '.') ?></td>
                            <td><?= date('d/m/Y', strtotime($item['tanggal_masuk'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php require_once 'includes/footer.php'; ?>