document.addEventListener('DOMContentLoaded', function() {
    // Show success/error messages
    if (typeof Toast !== 'undefined') {
        const successMessage = document.querySelector('.alert-success');
        const errorMessage = document.querySelector('.alert-danger');
        
        if (successMessage) {
            Toast.fire({
                icon: 'success',
                title: successMessage.textContent
            });
        }
        
        if (errorMessage) {
            Toast.fire({
                icon: 'error',
                title: errorMessage.textContent
            });
        }
    }
    
    // Initialize tooltips
    $('[data-toggle="tooltip"]').tooltip();
});